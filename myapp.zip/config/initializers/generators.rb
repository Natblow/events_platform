Rails.application.config.generators do |g|
  g.test_framework :rspec
end
