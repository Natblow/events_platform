module AttendeesHelper
end
